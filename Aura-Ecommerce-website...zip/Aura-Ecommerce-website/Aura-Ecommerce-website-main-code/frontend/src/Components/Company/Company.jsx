import React from 'react';
import './company.css';

const Company = () => {
  return (
    <div className="company-container">
      <div className="banner-section">
        {/* Banner image handled in CSS */}
        <h1>Join Our Team</h1>
        <p>Explore exciting job opportunities with us</p>
      </div>

      <div className="roles-section">
        <h2>Job Roles Available</h2>
        <ul>
          <li>Software Engineer</li>
          <li>Data Scientist</li>
          <li>Product Manager</li>
          <li>UX/UI Designer</li>
        </ul>
      </div>

      <div className="opportunities-section">
        <h2>Job Opportunities</h2>
        <p>
          We are looking for passionate and talented individuals to join our team. 
          If you have a knack for innovation and a drive for excellence, we want to hear from you!
        </p>
      </div>

      <div className="info-section">
        <div className="photo-section"></div> {/* Image will be handled in CSS */}
        <div className="location-section">
          <h2>Company Address</h2>
          <p>1234 Company Lane</p>
          <p>City, State, 12345</p>
        </div>
      </div>
    </div>
  );
};

export default Company;
