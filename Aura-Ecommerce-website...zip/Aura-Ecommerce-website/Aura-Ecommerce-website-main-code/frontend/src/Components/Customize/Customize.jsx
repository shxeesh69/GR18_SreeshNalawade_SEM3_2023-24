import React from 'react';
import './customize.css'; // Ensure this path is correct based on your project structure

const Customize = () => {
  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    const fileInput = document.getElementById("fileInput").files[0];
    formData.append("product", fileInput);

    try {
      const response = await fetch("http://localhost:4000/upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.json();
      console.log(result);
      alert(result.success ? "File uploaded successfully!" : "File upload failed.");
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("An error occurred during file upload.");
    }
  };

  return (
    <div>
      <div className="banner-image" /> {/* Banner image div */}
      <div className="hero-section">
        <h1>Customize your own design</h1>
        <p>Send us your own design, we will design it for you</p>
        <form id="uploadForm" onSubmit={handleSubmit} encType="multipart/form-data">
          <input type="file" id="fileInput" name="product" accept=".jpg,.jpeg,.png,.pdf" />
          <button type="submit">Upload Design</button>
        </form>
      </div>
    </div>
  );
};

export default Customize;
