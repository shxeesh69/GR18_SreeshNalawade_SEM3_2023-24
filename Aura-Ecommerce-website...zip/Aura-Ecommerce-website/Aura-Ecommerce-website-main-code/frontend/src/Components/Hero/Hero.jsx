import React from "react";
import "./Hero.css";
import hero from '../Assets/final maybe.mp4'

const Hero = () => {
  return (
    <div className="hero">
      <div className="video-background">
        <video className="bg-video" autoPlay muted loop>
          <source src={hero} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        {/* <div className="hero-text">TRENDINGZ</div> */}
      </div>
    </div>
  );
};

export default Hero;
