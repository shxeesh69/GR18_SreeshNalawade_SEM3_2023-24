import React from 'react';
import './sustainability.css';

const Sustainability = () => {
  return (
    <div className="sustainability">
       <div className="banner-image" /> {/* Banner image div */}
      <div className="hero-section">
        <h1>Customize your own design</h1>
        <p>Send us your own design, we will design it for you</p>
        <p className='content'>
          For almost 30 years, we’ve been working with sustainability. It’s part of our business idea – to offer our customers the best combination of fashion, quality, price and sustainability – and we believe that sustainable fashion should not be limited to the few.
        </p>
        <p>
          We’ve made a lot of progress, however there is still much more to do. Across our industry, we need to reduce our impact on the climate, improve our social impact and build a better fashion system. And we need to do this transparently.
        </p>
        <p>
          In this section of our website, you will find information on our goals and how we are going to reach them, as well as the standards and policies that guide our work.
        </p>
      </div>

      <div className="image-grid">
        <div className="square-image"></div>
        <div className="square-image"></div>
        <div className="square-image"></div>
      </div>

      <div className="sustainability-essentials">
        <h2>Sustainability Essentials</h2>
        <p>
          If you are new to our sustainability work, we recommend you visit these pages to get an overview of our work:
        </p>
        <ul>
          <li>Read an interview and watch a short video with Leyla Ertur, our Director of Sustainability, where she talks about our approach to sustainability, our biggest challenges and our focus areas.</li>
          <li>Discover what others are saying about us on our awards and recognitions page where we list some of the recent reports and rankings that have featured H&M Group.</li>
          <li>Explore our Sustainability Disclosure, where we set out in detail what we have achieved and learnt during the previous year as well as listing what we will focus on in the next.</li>
        </ul>
      </div>

      <div className="center-image">
        <div className="large-image"></div>
        <p>
          This is a sample paragraph providing additional information related to sustainability practices, initiatives, and ongoing commitments to ensure a greener future for all.
        </p>
      </div>
    </div>
  );
};

export default Sustainability;
